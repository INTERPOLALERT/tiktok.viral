// TikTok Viral Website - Main JavaScript
class TikTokViralApp {
    constructor() {
        this.currentLanguage = 'uk';
        this.userXP = 0;
        this.userStreak = 0;
        this.currentCardIndex = 0;
        this.isLiveAlertEnabled = true;
        this.battleScore = { player: 0, ai: 0 };
        this.battleRound = 0;
        this.maxRounds = 5;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeAnimations();
        this.loadUserProgress();
        this.startLiveAlertSystem();
    }

    setupEventListeners() {
        // Language toggle
        const langToggle = document.getElementById('langToggle');
        if (langToggle) {
            langToggle.addEventListener('click', () => this.toggleLanguage());
        }

        // Feed navigation
        const feedContainer = document.getElementById('feedContainer');
        if (feedContainer) {
            feedContainer.addEventListener('wheel', (e) => this.handleFeedScroll(e));
            feedContainer.addEventListener('touchstart', (e) => this.handleTouchStart(e));
            feedContainer.addEventListener('touchend', (e) => this.handleTouchEnd(e));
        }

        // Battle controls
        const battleButtons = document.querySelectorAll('.battle-option');
        battleButtons.forEach(button => {
            button.addEventListener('click', (e) => this.handleBattleAnswer(e));
        });

        // Spin wheel
        const spinButton = document.getElementById('spinWheel');
        if (spinButton) {
            spinButton.addEventListener('click', () => this.spinWheel());
        }

        // Live alert toggle
        const alertToggle = document.getElementById('liveAlertToggle');
        if (alertToggle) {
            alertToggle.addEventListener('change', (e) => this.toggleLiveAlert(e));
        }

        // Navigation
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => this.handleNavigation(e));
        });
    }

    initializeAnimations() {
        // Initialize text animations
        if (typeof Splitting !== 'undefined') {
            Splitting();
        }

        // Typewriter effect for hero text
        if (typeof Typed !== 'undefined') {
            const heroText = document.getElementById('heroText');
            if (heroText) {
                new Typed('#heroText', {
                    strings: [
                        'TikTok Viral',
                        'Вивчай English',
                        'Learn Ukrainian → English',
                        'Допоможи собі!'
                    ],
                    typeSpeed: 100,
                    backSpeed: 50,
                    backDelay: 2000,
                    loop: true,
                    showCursor: true,
                    cursorChar: '|'
                });
            }
        }

        // Initialize scroll animations
        this.initScrollAnimations();
    }

    initScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        // Observe all animatable elements
        document.querySelectorAll('.animate-on-scroll').forEach(el => {
            observer.observe(el);
        });
    }

    // Feed Simulation
    createFeedCard(data) {
        const card = document.createElement('div');
        card.className = 'feed-card bg-white rounded-lg shadow-lg p-6 mb-4 animate-on-scroll';
        
        card.innerHTML = `
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <img src="${data.userAvatar}" alt="User" class="w-10 h-10 rounded-full mr-3">
                    <div>
                        <p class="font-semibold text-gray-800">${data.username}</p>
                        <p class="text-sm text-gray-500">${data.timestamp}</p>
                    </div>
                </div>
                <button class="text-gray-400 hover:text-red-500 transition-colors">
                    <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z"/>
                    </svg>
                </button>
            </div>
            
            <div class="mb-4">
                ${data.content}
            </div>
            
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <button class="audio-btn flex items-center text-blue-600 hover:text-blue-800 transition-colors" data-audio="${data.audio}">
                        <svg class="w-5 h-5 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.617.793L4.828 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.828l3.555-3.793A1 1 0 019.383 3.076zM15 8a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                        🔊 Listen
                    </button>
                    <button class="text-yellow-600 hover:text-yellow-800 transition-colors">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        Master
                    </button>
                </div>
                <div class="text-sm text-gray-500">
                    +${data.xp} XP
                </div>
            </div>
        `;

        // Add audio functionality
        const audioBtn = card.querySelector('.audio-btn');
        audioBtn.addEventListener('click', () => this.playAudio(data.audio));

        return card;
    }

    handleFeedScroll(e) {
        e.preventDefault();
        const delta = e.deltaY;
        
        if (delta > 0) {
            this.nextCard();
        } else {
            this.prevCard();
        }
    }

    handleTouchStart(e) {
        this.touchStartY = e.touches[0].clientY;
    }

    handleTouchEnd(e) {
        const touchEndY = e.changedTouches[0].clientY;
        const delta = this.touchStartY - touchEndY;
        
        if (Math.abs(delta) > 50) {
            if (delta > 0) {
                this.nextCard();
            } else {
                this.prevCard();
            }
        }
    }

    nextCard() {
        const cards = document.querySelectorAll('.feed-card');
        if (this.currentCardIndex < cards.length - 1) {
            this.currentCardIndex++;
            this.animateCardTransition(cards[this.currentCardIndex - 1], cards[this.currentCardIndex]);
        }
    }

    prevCard() {
        const cards = document.querySelectorAll('.feed-card');
        if (this.currentCardIndex > 0) {
            this.currentCardIndex--;
            this.animateCardTransition(cards[this.currentCardIndex + 1], cards[this.currentCardIndex]);
        }
    }

    animateCardTransition(fromCard, toCard) {
        if (typeof anime !== 'undefined') {
            anime({
                targets: fromCard,
                translateY: -100,
                opacity: 0,
                duration: 300,
                easing: 'easeOutQuad'
            });

            anime({
                targets: toCard,
                translateY: [100, 0],
                opacity: [0, 1],
                duration: 300,
                easing: 'easeOutQuad'
            });
        }
    }

    // Battle System
    startBattle() {
        this.battleScore = { player: 0, ai: 0 };
        this.battleRound = 0;
        this.nextBattleRound();
    }

    nextBattleRound() {
        if (this.battleRound >= this.maxRounds) {
            this.endBattle();
            return;
        }

        this.battleRound++;
        const question = this.getRandomQuestion();
        this.displayBattleQuestion(question);
        this.startBattleTimer();
    }

    getRandomQuestion() {
        const questions = [
            {
                question: 'Як буде "Hello" українською?',
                options: ['Привіт', 'Дякую', 'Будь ласка', 'До побачення'],
                correct: 0,
                english: 'Hello'
            },
            {
                question: 'What is "Дякую" in English?',
                options: ['Hello', 'Thank you', 'Please', 'Goodbye'],
                correct: 1,
                english: 'Thank you'
            },
            {
                question: 'Як буде "Good morning" українською?',
                options: ['Добраніч', 'Добрий день', 'Доброго ранку', 'До побачення'],
                correct: 2,
                english: 'Good morning'
            }
        ];

        return questions[Math.floor(Math.random() * questions.length)];
    }

    displayBattleQuestion(question) {
        const questionEl = document.getElementById('battleQuestion');
        const optionsEl = document.getElementById('battleOptions');
        
        if (questionEl) questionEl.textContent = question.question;
        
        if (optionsEl) {
            optionsEl.innerHTML = '';
            question.options.forEach((option, index) => {
                const button = document.createElement('button');
                button.className = 'battle-option bg-white hover:bg-blue-50 border-2 border-blue-200 rounded-lg p-4 text-left transition-all duration-200';
                button.textContent = option;
                button.dataset.index = index;
                button.addEventListener('click', (e) => this.handleBattleAnswer(e, question));
                optionsEl.appendChild(button);
            });
        }
    }

    handleBattleAnswer(e, question) {
        const selectedIndex = parseInt(e.target.dataset.index);
        const isCorrect = selectedIndex === question.correct;
        
        if (isCorrect) {
            this.battleScore.player += 20;
            this.showBattleFeedback(true);
        } else {
            this.battleScore.ai += 20;
            this.showBattleFeedback(false);
        }
        
        this.updateBattleProgress();
        
        setTimeout(() => {
            this.nextBattleRound();
        }, 2000);
    }

    showBattleFeedback(isCorrect) {
        const feedback = document.createElement('div');
        feedback.className = `battle-feedback fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 ${isCorrect ? 'bg-green-500' : 'bg-red-500'} text-white px-8 py-4 rounded-lg text-xl font-bold`;
        feedback.textContent = isCorrect ? 'Правильно! ✓' : 'Неправильно! ✗';
        
        document.body.appendChild(feedback);
        
        if (typeof anime !== 'undefined') {
            anime({
                targets: feedback,
                scale: [0, 1],
                opacity: [0, 1],
                duration: 300,
                easing: 'easeOutBack',
                complete: () => {
                    setTimeout(() => {
                        anime({
                            targets: feedback,
                            scale: [1, 0],
                            opacity: [1, 0],
                            duration: 300,
                            easing: 'easeInBack',
                            complete: () => feedback.remove()
                        });
                    }, 1500);
                }
            });
        }
    }

    updateBattleProgress() {
        const playerBar = document.getElementById('playerProgress');
        const aiBar = document.getElementById('aiProgress');
        
        if (playerBar) {
            playerBar.style.width = `${this.battleScore.player}%`;
        }
        if (aiBar) {
            aiBar.style.width = `${this.battleScore.ai}%`;
        }
    }

    startBattleTimer() {
        let timeLeft = 15;
        const timerEl = document.getElementById('battleTimer');
        
        const timer = setInterval(() => {
            timeLeft--;
            if (timerEl) timerEl.textContent = timeLeft;
            
            if (timeLeft <= 0) {
                clearInterval(timer);
                this.battleScore.ai += 10;
                this.updateBattleProgress();
                this.nextBattleRound();
            }
        }, 1000);
    }

    endBattle() {
        const winner = this.battleScore.player > this.battleScore.ai ? 'player' : 'ai';
        this.showBattleResult(winner);
    }

    showBattleResult(winner) {
        const resultModal = document.createElement('div');
        resultModal.className = 'battle-result fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        resultModal.innerHTML = `
            <div class="bg-white rounded-lg p-8 max-w-md mx-4 text-center">
                <h2 class="text-2xl font-bold mb-4 ${winner === 'player' ? 'text-green-600' : 'text-red-600'}">
                    ${winner === 'player' ? 'Перемога! 🏆' : 'Поразка! 😔'}
                </h2>
                <p class="text-gray-600 mb-4">
                    Рахунок: ${this.battleScore.player} - ${this.battleScore.ai}
                </p>
                <p class="text-sm text-gray-500 mb-6">
                    ${winner === 'player' ? '+50 XP' : '+10 XP'}
                </p>
                <button class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors" onclick="this.parentElement.parentElement.remove()">
                    Грати ще раз
                </button>
            </div>
        `;
        
        document.body.appendChild(resultModal);
        
        if (winner === 'player') {
            this.userXP += 50;
        } else {
            this.userXP += 10;
        }
        
        this.updateUserProgress();
    }

    // Spin Wheel
    spinWheel() {
        const wheel = document.getElementById('wheel');
        if (!wheel) return;
        
        const spins = Math.random() * 3600 + 1800; // 5-15 full rotations
        const finalRotation = spins + (Math.random() * 360);
        
        if (typeof anime !== 'undefined') {
            anime({
                targets: wheel,
                rotate: finalRotation,
                duration: 3000,
                easing: 'easeOutCubic',
                complete: () => {
                    this.showWheelResult();
                }
            });
        }
    }

    showWheelResult() {
        const prizes = [
            { name: '10 XP', color: 'green' },
            { name: 'Pro Features (1 day)', color: 'blue' },
            { name: 'Try again', color: 'gray' },
            { name: '50 XP', color: 'gold' },
            { name: 'Special badge', color: 'purple' },
            { name: 'Free spin', color: 'yellow' }
        ];
        
        const prize = prizes[Math.floor(Math.random() * prizes.length)];
        
        const result = document.createElement('div');
        result.className = `wheel-result fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-${prize.color}-500 text-white px-8 py-4 rounded-lg text-xl font-bold z-50`;
        result.textContent = `Ви виграли: ${prize.name}!`;
        
        document.body.appendChild(result);
        
        setTimeout(() => result.remove(), 3000);
    }

    // Live Alert System
    startLiveAlertSystem() {
        if (!this.isLiveAlertEnabled) return;
        
        // Simulate live alerts every 30-60 seconds
        setInterval(() => {
            if (Math.random() < 0.3) { // 30% chance
                this.showLiveAlert();
            }
        }, 45000);
    }

    showLiveAlert() {
        const alert = document.createElement('div');
        alert.className = 'live-alert fixed top-4 right-4 bg-blue-600 text-white p-4 rounded-lg shadow-lg z-50 max-w-sm';
        alert.innerHTML = `
            <div class="flex items-center">
                <div class="w-3 h-3 bg-red-500 rounded-full mr-2 animate-pulse"></div>
                <div>
                    <p class="font-semibold">@aya.liona is LIVE!</p>
                    <p class="text-sm opacity-90">"Going live" = стрімити</p>
                    <button class="text-xs underline mt-1" onclick="window.open('https://tiktok.com/@aya.liona', '_blank')">
                        Watch on TikTok →
                    </button>
                </div>
                <button class="ml-2 text-white opacity-70 hover:opacity-100" onclick="this.parentElement.parentElement.remove()">
                    ×
                </button>
            </div>
        `;
        
        document.body.appendChild(alert);
        
        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (alert.parentElement) {
                alert.remove();
            }
        }, 10000);
    }

    toggleLiveAlert(e) {
        this.isLiveAlertEnabled = e.target.checked;
    }

    // Language Toggle
    toggleLanguage() {
        this.currentLanguage = this.currentLanguage === 'uk' ? 'en' : 'uk';
        this.updateLanguage();
    }

    updateLanguage() {
        const elements = document.querySelectorAll('[data-lang]');
        elements.forEach(el => {
            const key = el.dataset.lang;
            if (this.translations[key] && this.translations[key][this.currentLanguage]) {
                el.textContent = this.translations[key][this.currentLanguage];
            }
        });
    }

    translations = {
        'appTitle': {
            'uk': 'TiktokViral369',
            'en': 'TiktokViral369'
        },
        'appSubtitle': {
            'uk': 'Вивчай English по-новому',
            'en': 'Learn English the TikTok way'
        },
        'downloadButton': {
            'uk': 'Завантажити зараз',
            'en': 'Download Now'
        },
        'featuresTitle': {
            'uk': 'Функції додатку',
            'en': 'App Features'
        }
    };

    // Audio System
    playAudio(text) {
        // Simulate audio playback with TTS
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = this.currentLanguage === 'uk' ? 'uk-UA' : 'en-US';
            utterance.rate = 0.8;
            speechSynthesis.speak(utterance);
        }
    }

    // Progress System
    loadUserProgress() {
        const saved = localStorage.getItem('tiktokViralProgress');
        if (saved) {
            const progress = JSON.parse(saved);
            this.userXP = progress.xp || 0;
            this.userStreak = progress.streak || 0;
        }
        this.updateUserProgress();
    }

    updateUserProgress() {
        const xpEl = document.getElementById('userXP');
        const streakEl = document.getElementById('userStreak');
        
        if (xpEl) xpEl.textContent = this.userXP;
        if (streakEl) streakEl.textContent = this.userStreak;
        
        // Save to localStorage
        localStorage.setItem('tiktokViralProgress', JSON.stringify({
            xp: this.userXP,
            streak: this.userStreak
        }));
    }

    // Navigation
    handleNavigation(e) {
        e.preventDefault();
        const href = e.target.getAttribute('href');
        if (href && href !== '#') {
            window.location.href = href;
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.tiktokViralApp = new TikTokViralApp();
});

// Particle system for hero background
function initParticles() {
    if (typeof p5 === 'undefined') return;
    
    new p5((p) => {
        let particles = [];
        
        p.setup = () => {
            const canvas = p.createCanvas(p.windowWidth, p.windowHeight);
            canvas.parent('heroParticles');
            canvas.style('position', 'absolute');
            canvas.style('top', '0');
            canvas.style('left', '0');
            canvas.style('z-index', '1');
            
            // Create particles
            for (let i = 0; i < 50; i++) {
                particles.push({
                    x: p.random(p.width),
                    y: p.random(p.height),
                    vx: p.random(-1, 1),
                    vy: p.random(-1, 1),
                    size: p.random(2, 6),
                    color: p.random(['#005BBB', '#FFD700', '#FFFFFF'])
                });
            }
        };
        
        p.draw = () => {
            p.clear();
            
            particles.forEach(particle => {
                p.fill(particle.color + '40');
                p.noStroke();
                p.ellipse(particle.x, particle.y, particle.size);
                
                particle.x += particle.vx;
                particle.y += particle.vy;
                
                if (particle.x < 0 || particle.x > p.width) particle.vx *= -1;
                if (particle.y < 0 || particle.y > p.height) particle.vy *= -1;
            });
        };
        
        p.windowResized = () => {
            p.resizeCanvas(p.windowWidth, p.windowHeight);
        };
    });
}