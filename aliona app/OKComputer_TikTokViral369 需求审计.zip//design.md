# TikTok Viral Website - Design Style Guide

## Design Philosophy

### Visual Language
- **Ukrainian Soul**: Deep blue (#005BBB) and sunflower yellow (#FFD700) as primary colors
- **TikTok DNA**: Vertical scrolling, swipe gestures, minimal UI chrome
- **Cultural Authenticity**: Vyshyvanka-inspired patterns, sunflower motifs, Tryzub symbols
- **Modern Minimalism**: Clean typography, generous whitespace, focused content

### Color Palette
- **Primary Blue**: #005BBB (Ukrainian Blue)
- **Accent Yellow**: #FFD700 (Sunflower Yellow)
- **Background Light**: #F5F5F5
- **Background Dark**: #1A1A1A
- **Success Green**: #4CAF50
- **Warning Orange**: #FF9800
- **Error Red**: #F44336
- **Text Primary**: #212121
- **Text Secondary**: #757575

### Typography
- **Display Font**: "Playfair Display" - Bold serif for Ukrainian headings
- **Body Font**: "Inter" - Clean sans-serif for English content
- **Accent Font**: "SF Pro Display" - iOS-inspired for app elements
- **Font Sizes**: Mobile-optimized with large headings and readable body text

## Visual Effects

### Used Libraries
- **Anime.js**: Smooth animations and transitions
- **Splitting.js**: Text animation effects
- **Typed.js**: Typewriter effects for dynamic content
- **p5.js**: Ukrainian flag particle effects
- **ECharts.js**: Progress visualization
- **Splide**: Image carousels and sliders
- **Pixi.js**: Interactive visual effects

### Animation Effects
- **Scroll Animations**: Subtle fade-in and slide-up effects
- **Hover Effects**: 3D tilt, glow, and shadow animations
- **Loading States**: Ukrainian-themed loading animations
- **Micro-interactions**: Button press feedback, card flips
- **Particle Systems**: Floating sunflower petals, flag particles

### Header Effects
- **Hero Background**: Animated Ukrainian flag with particle system
- **Typewriter Animation**: App name with color cycling
- **Gradient Overlays**: Blue-to-yellow gradients
- **Floating Elements**: Subtle geometric shapes

### Interactive Elements
- **Cards**: Flip animations with Ukrainian embroidery borders
- **Buttons**: Pulse effects with Ukrainian colors
- **Progress Bars**: Animated fills with sunflower icons
- **Modals**: Slide-in animations with backdrop blur
- **Navigation**: Smooth transitions between sections

## Layout Principles

### Grid System
- **Mobile-First**: Responsive design starting from 320px
- **Vertical Flow**: TikTok-inspired vertical scrolling
- **Card-Based**: Content organized in swipeable cards
- **Full-Screen**: Immersive experiences without chrome

### Spacing
- **Consistent**: 8px base unit system
- **Generous**: Ample whitespace for readability
- **Breathing Room**: Comfortable content spacing
- **Visual Hierarchy**: Clear content organization

### Visual Hierarchy
- **Primary**: Large headings with Ukrainian colors
- **Secondary**: Medium subheadings in neutral colors
- **Tertiary**: Body text with good contrast
- **Accent**: Highlighted elements in sunflower yellow

## Cultural Elements

### Ukrainian Motifs
- **Vyshyvanka Patterns**: Traditional embroidery borders
- **Sunflower Imagery**: Growth, learning, Ukraine
- **Tryzub Symbol**: Achievement badges and icons
- **Flag Colors**: Consistent blue and yellow usage
- **Folk Art**: Geometric patterns and ornaments

### Modern Integration
- **Minimal Application**: Subtle cultural touches
- **Contemporary Layout**: Clean, modern presentation
- **Functional Design**: Culture serves usability
- **Respectful Representation**: Authentic Ukrainian elements

## Responsive Behavior

### Mobile Optimization
- **Touch-Friendly**: Large tap targets
- **Swipe Gestures**: TikTok-inspired navigation
- **Vertical Layout**: Optimized for portrait mode
- **Fast Loading**: Optimized images and animations

### Desktop Enhancement
- **Hover States**: Rich interactive feedback
- **Larger Canvas**: Expanded layouts
- **Multi-Column**: Efficient space usage
- **Enhanced Effects**: More complex animations